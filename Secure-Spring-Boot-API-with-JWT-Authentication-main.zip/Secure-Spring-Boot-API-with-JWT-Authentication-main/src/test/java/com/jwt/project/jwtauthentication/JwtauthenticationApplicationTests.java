package com.jwt.project.jwtauthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtauthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
